﻿from typing import Optional, Tuple
import pandas as pd
import pytz
from datetime import datetime
import MetaTrader5 as mt5

TIMEFRAME = {
    "M1":  mt5.TIMEFRAME_M1,
    "M5":  mt5.TIMEFRAME_M5,
    "M15": mt5.TIMEFRAME_M15,
    "M30": mt5.TIMEFRAME_M30,
    "H1":  mt5.TIMEFRAME_H1,
    "H4":  mt5.TIMEFRAME_H4,
    "D1":  mt5.TIMEFRAME_D1,
}

def init_mt5() -> None:
    if not mt5.initialize():
        raise RuntimeError(f"MT5 initialize failed: {mt5.last_error()}")

def shutdown_mt5() -> None:
    try:
        mt5.shutdown()
    except Exception:
        pass

def pull_bars_mt5(symbol: str, tf: str, start_utc: datetime, end_utc: datetime, ensure_visible: bool = True) -> pd.DataFrame:
    if start_utc.tzinfo is None or end_utc.tzinfo is None:
        raise ValueError("start_utc and end_utc must be timezone-aware UTC datetimes")
    if ensure_visible:
        mt5.symbol_select(symbol, True)
    tf_enum = TIMEFRAME[tf]
    rates = mt5.copy_rates_range(symbol, tf_enum, start_utc, end_utc)
    if rates is None or len(rates) == 0:
        raise RuntimeError(f"No data returned for {symbol} {tf} between {start_utc} and {end_utc}.")
    df = pd.DataFrame(rates)
    df['time'] = pd.to_datetime(df['time'], unit='s', utc=True)
    df = df.rename(columns={'time':'datetime'}).set_index('datetime').sort_index()
    keep = [c for c in ['open','high','low','close','tick_volume','real_volume','spread'] if c in df.columns]
    return df[keep]

def save_parquet(df: pd.DataFrame, path: str) -> None:
    if df.index.tz is None:
        df = df.tz_localize('UTC')
    df.to_parquet(path)