from dataclasses import dataclass
from typing import Dict, Any, Callable, Optional, Tuple
import numpy as np
import pandas as pd

@dataclass
class FillModel:
    spread_pips: float = 0.8
    slippage_pips: float = 0.2

class Simulator:
    """
    Minimal bar-by-bar loop:
      - calls exit_fn each bar if a position exists
      - calls entry_fn when flat to open a new position
      - acts with latency_bars (next bar open) to avoid look-ahead
    Expects bars: DataFrame with index datetime, columns ['open','high','low','close'].
    """
    def __init__(self, bars: pd.DataFrame, cfg: Dict[str, Any],
                 entry_fn: Callable, exit_fn: Callable, sizer_fn: Callable,
                 fill: FillModel):
        self.bars = bars.sort_index()
        self.cfg = cfg
        self.entry_fn = entry_fn
        self.exit_fn = exit_fn
        self.sizer_fn = sizer_fn
        self.fill = fill
        self.trades = []

    def run(self, seed: int = 7) -> pd.DataFrame:
        rng = np.random.default_rng(seed)
        pos: Optional[Dict[str, Any]] = None
        equity = float(self.cfg.get('start_equity', 10000.0))
        series_state = self.cfg.get('series_state', {'series_start_equity': equity})
        latency = int(self.cfg.get('latency_bars', 1))

        O, H, L, C = (self.bars['open'], self.bars['high'], self.bars['low'], self.bars['close'])

        for i in range(len(self.bars) - latency):
            t = self.bars.index[i]
            nxt_t = self.bars.index[i + latency]
            row = self.bars.iloc[i]
            nxt_row = self.bars.iloc[i + latency]

            # 1) manage exit if in position
            if pos is not None:
                pos, evt = self.exit_fn(pos, row, nxt_row, self.fill)
                if evt is not None:
                    # record P&L event at next-bar time
                    evt_rec = {**evt, 'time_exit': nxt_t}
                    self.trades.append(evt_rec)
                    equity += float(evt.get('pnl', 0.0))
                    pos = None

            # 2) if flat, consider entry
            if pos is None:
                sig = self.entry_fn(i, self.bars, rng)
                if sig is not None:
                    size, risk_meta = self.sizer_fn(equity, series_state, sig, self.cfg)
                    if size and size > 0:
                        pos = {
                            'side': sig['side'],               # 'long' or 'short'
                            'entry_px': float(nxt_row['open']),# enter at next bar open
                            'size': float(size),
                            'meta': dict(risk_meta or {}),
                        }

        return pd.DataFrame(self.trades)
