﻿# src/evaluation.py
# Metrics & summaries
import numpy as np
import pandas as pd

def equity_curve(trades: pd.DataFrame, start_equity: float = 10000.0) -> pd.Series:
    ec = pd.Series([start_equity], index=[pd.Timestamp.min.tz_localize('UTC')])
    if 'pnl' in trades:
        pnl = trades['pnl'].cumsum()
        idx = trades.get('time_exit', pd.RangeIndex(len(trades)))
        ec = pd.Series(start_equity + pnl.values, index=idx)
    return ec.sort_index()

def max_drawdown(series: pd.Series) -> float:
    roll_max = series.cummax()
    dd = (series - roll_max) / roll_max
    return float(dd.min())

def expectancy(trades: pd.DataFrame) -> float:
    if 'pnl' not in trades or len(trades)==0: return 0.0
    return trades['pnl'].mean()

def win_rate(trades: pd.DataFrame) -> float:
    if 'pnl' not in trades or len(trades)==0: return 0.0
    return float((trades['pnl'] > 0).mean())

def top_n_contrib(trades: pd.DataFrame, n: int = 10) -> float:
    if 'pnl' not in trades or len(trades)==0: return 0.0
    pnl_sorted = trades['pnl'].sort_values(ascending=False)
    return float(pnl_sorted.head(n).sum())