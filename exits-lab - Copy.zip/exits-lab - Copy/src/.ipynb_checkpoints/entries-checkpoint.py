# src/entries.py
from typing import Optional, Dict
import numpy as np
import pandas as pd

def random_entry(i: int,
                 bars: pd.DataFrame,
                 rng: np.random.Generator,
                 prob: float = 0.02,
                 min_bars_between: int = 5,
                 session_mask: Optional[pd.Series] = None) -> Optional[Dict]:
    """
    Stateless random entry generator.
    - prob: per-bar probability of generating a signal (e.g., 0.02 = 2%)
    - min_bars_between: throttle so we don't enter every bar
    - session_mask: optional boolean Series aligned to bars.index (True = may enter)
    Returns: dict like {'side': 'long'|'short'} or None for no entry.
    """
    # respect session mask if provided
    if session_mask is not None:
        # fast check for aligned index
        if session_mask.index is bars.index and not bool(session_mask.iat[i]):
            return None
        # if not aligned, just check by timestamp
        elif session_mask.index is not bars.index:
            if not bool(session_mask.reindex([bars.index[i]], method=None).iloc[0]):
                return None

    # simple throttle using modulo buckets so it is deterministic per index
    # (avoids needing persistent state)
    if (i % max(1, min_bars_between)) != 0:
        return None

    if rng.random() < prob:
        side = 'long' if rng.random() < 0.5 else 'short'
        return {'side': side}

    return None
