import pandas as pd
import numpy as np

# --- ATR (Wilder's mean true range) ---
def add_atr(df: pd.DataFrame, n: int = 14) -> pd.DataFrame:
    hi, lo, cl = df['high'], df['low'], df['close']
    prev_close = cl.shift(1)
    tr = pd.concat([
        (hi - lo),
        (hi - prev_close).abs(),
        (lo - prev_close).abs()
    ], axis=1).max(axis=1)
    atr = tr.rolling(n, min_periods=n).mean()
    df['atr'] = atr
    return df

# --- Spread conversions & ratios ---
# For most FX brokers, MT5 'spread' is in *points* (in digits of the symbol)
# We'll compute: spread_pips, atr_pips, and spread_to_atr
def add_spread_features(df: pd.DataFrame, pip_size: float = 1e-4) -> pd.DataFrame:
    # raw MT5 spread = integer points
    df['spread_points'] = df['spread'].astype(float)

    # Assume 5-digit EURUSD: 10 points = 1 pip
    df['spread_pips'] = df['spread_points'] / 10.0

    # ATR is in price units (e.g. 0.00012). Convert to pips
    df['atr_pips'] = df['atr'] / pip_size

    # Ratio
    df['spread_to_atr'] = df['spread_pips'] / df['atr_pips']
    return df


# --- Volatility compression (ATR vs. longer baseline) ---
def add_vol_compression(df: pd.DataFrame, short: int = 14, long: int = 42) -> pd.DataFrame:
    if 'atr' not in df:
        add_atr(df, n=short)
    base = df['atr'].rolling(long, min_periods=long).mean()
    df['atr_compression'] = df['atr'] / base
    return df

# --- Session tagging (UTC) ---
# Default session windows (UTC); tweak if needed
SESSIONS = {
    'london': ('07:00', '11:00'),
    'overlap': ('12:30', '15:30'),
    'ny': ('12:30', '20:00'),
    'asia': ('23:00', '06:00'),
}

def _in_window(ts, start_str, end_str):
    start = pd.to_datetime(start_str).time()
    end = pd.to_datetime(end_str).time()
    t = ts.time()
    if start <= end:
        return (t >= start) & (t < end)
    else:
        # overnight window
        return (t >= start) | (t < end)

def add_session_tags(df: pd.DataFrame, sessions: dict = None) -> pd.DataFrame:
    if sessions is None:
        sessions = SESSIONS
    for name, (s, e) in sessions.items():
        df[f'session_{name}'] = df.index.map(lambda ts: _in_window(ts, s, e))
    # One-hot primary session (the first True wins: london > overlap > ny > asia)
    order = ['london','overlap','ny','asia']
    def _label(ts):
        for nm in order:
            if _in_window(ts, *sessions[nm]):
                return nm
        return 'other'
    df['session_label'] = df.index.map(_label)
    return df

# --- Convenience to build all features and drop NaNs ---
def build_features(df: pd.DataFrame,
                   atr_n: int = 14,
                   comp_short: int = 14,
                   comp_long: int = 42,
                   pip_size: float = 1e-4) -> pd.DataFrame:
    df = df.copy()
    # ensure UTC index
    if df.index.tz is None:
        df = df.tz_localize('UTC')
    add_atr(df, n=atr_n)
    add_vol_compression(df, short=comp_short, long=comp_long)
    add_spread_features(df, pip_size=pip_size)
    add_session_tags(df)
    # drop warmup NaNs
    df = df.dropna()
    return df
