﻿# src/policy.py
# Labeling + simple ML (placeholder)
from typing import List, Dict, Any
import pandas as pd

def label_best_policy(results: pd.DataFrame, utility_cols: List[str]) -> pd.Series:
    # Pick the policy (exit, size-tier) with max utility
    if not utility_cols: raise ValueError('utility_cols empty')
    util = results[utility_cols].sum(axis=1)
    return results.loc[util.groupby(results.index).idxmax(), 'policy'] if 'policy' in results else util.idxmax()