﻿# src/series.py
# State machine for goal/cut-out sequences
from dataclasses import dataclass

@dataclass
class SeriesState:
    series_start_equity: float
    cutout_pct: float
    goal_pct: float
    used_stop_hits: int = 0
    status: str = "INIT"   # INIT -> ACTIVE -> GOAL_HIT/CUTOUT_HIT -> RESET

def start_series(equity: float, cutout_pct: float, goal_pct: float) -> SeriesState:
    return SeriesState(series_start_equity=equity, cutout_pct=cutout_pct, goal_pct=goal_pct, status="ACTIVE")

def progress_to_goal(equity: float, st: SeriesState) -> float:
    goal = st.series_start_equity * st.goal_pct
    return max(0.0, min(1.0, (equity - st.series_start_equity) / max(1e-9, goal)))

def buffer_from_cutout(equity: float, st: SeriesState) -> float:
    cutout = st.series_start_equity * st.cutout_pct
    dd = st.series_start_equity - equity
    return max(0.0, 1.0 - (dd / max(1e-9, cutout)))

def is_goal_hit(equity: float, st: SeriesState) -> bool:
    return equity >= st.series_start_equity * (1.0 + st.goal_pct)

def is_cutout_hit(equity: float, st: SeriesState) -> bool:
    return equity <= st.series_start_equity * (1.0 - st.cutout_pct)